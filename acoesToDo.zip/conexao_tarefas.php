<?php
$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'tarefas';

$conexao = mysqli_connect($host,$usuario,$senha,$banco) or die('Não foi possível conectar')

?>